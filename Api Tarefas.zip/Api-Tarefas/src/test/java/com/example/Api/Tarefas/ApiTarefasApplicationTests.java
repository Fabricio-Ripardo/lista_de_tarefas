package com.example.Api.Tarefas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTarefasApplicationTests {

	@Test
	void contextLoads() {
	}

}
